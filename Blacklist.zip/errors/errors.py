class ApiError(Exception):
    code = 422
    description = "Default message"